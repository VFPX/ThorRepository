#Define	OuterMargin 		6
#Define HorzBetween 		10
#Define VertBetween 		4
#Define TopMargin 			6

#Define LeftSpecialsOnLeft  40
#Define TopSpecialsOnTop    30

